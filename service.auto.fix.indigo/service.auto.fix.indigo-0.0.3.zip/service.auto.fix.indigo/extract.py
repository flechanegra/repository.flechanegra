import zipfile, xbmcaddon, xbmc, sys, os, time

AddonID = xbmcaddon.Addon().getAddonInfo('id')
ADDON = xbmcaddon.Addon(id=AddonID) 
ADDONTITLE = ADDON.getAddonInfo('name')
COLOR1 = 'red'
COLOR2 = 'springgreen'
COLOR3 = 'blue'
HOME           = xbmc.translatePath('special://home/')
USERDATA       = os.path.join(HOME,      'userdata')
KODIV          = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
LOGFILES       = ['xbmc.log', 'xbmc.old.log', 'kodi.log', 'kodi.old.log', 'spmc.log', 'spmc.old.log', 'tvmc.log', 'tvmc.old.log', 'Thumbs.db', '.gitignore', '.DS_Store']
bad_files      = ['onechannelcache.db', 'saltscache.db', 'saltscache.db-shm', 'saltscache.db-wal', 'saltshd.lite.db', 'saltshd.lite.db-shm', 'saltshd.lite.db-wal', 'queue.db', 'commoncache.db', 'access.log', 'trakt.db', 'video_cache.db']
ADDONDATA      = os.path.join(USERDATA,  'addon_data', AddonID)
WIZLOG         = os.path.join(ADDONDATA, 'wizard.log')
PASSWORD       = ADDON.getSetting('password')

def getS(name):
	try: return ADDON.getSetting(name)
	except: return False

def setS(name, value):
	try: ADDON.setSetting(name, value)
	except: return False

def openS(name=""):
	ADDON.openSettings()

def convertSize(num, suffix='B'):
	for unit in ['', 'K', 'M', 'G']:
		if abs(num) < 1024.0:
			return "%3.02f %s%s" % (num, unit, suffix)
		num /= 1024.0
	return "%.02f %s%s" % (num, 'G', suffix)	

def log(msg, level=xbmc.LOGDEBUG):
	if not os.path.exists(ADDONDATA): os.makedirs(ADDONDATA)
	if not os.path.exists(WIZLOG): f = open(WIZLOG, 'w'); f.close()
	try:
		if isinstance(msg, unicode):
			msg = '%s' % (msg.encode('utf-8'))
		xbmc.log('%s: %s' % (ADDONTITLE, msg), level)
	except Exception as e:
		try: xbmc.log('Logging Failure: %s' % (e), level)
		except: pass
			
def all(_in, _out, dp=None, ignore=None, title=None, pwd= PASSWORD):
	if dp: return allWithProgress(_in, _out, dp, ignore, title)
	else: return allNoProgress(_in, _out, ignore, pwd= PASSWORD)

def allNoProgress(_in, _out, ignore, pwd= PASSWORD):
	try:
		zin = zipfile.ZipFile(_in, 'r')
		zin.extractall(_out, pwd= PASSWORD)
	except Exception, e:
		print str(e)
		return False
	return True

def allWithProgress(_in, _out, dp, ignore, title):
	count = 0; errors = 0; error = ''; update = 0; size = 0; excludes = []
	try:	        			
		zin = zipfile.ZipFile(_in,  'r')     		
		nFiles = float(len(zin.infolist()))				
		count = 0			
	except Exception, e:
		errors += 1; error += '%s\n' % e
		log('Error Checking Zip: %s' % str(e), xbmc.LOGERROR)
		return update, errors, error

    
	nFiles = float(len(zin.namelist()))	
	zipsize = convertSize(sum([item.file_size for item in zin.infolist()]))
	
	for item in zin.infolist():        	
		count += 1; prog = int(count / nFiles * 100); size += item.file_size
		file = str(item.filename).split('/')
		skip = False
		line1  = '%s [COLOR %s][B][Errors:%s][/B][/COLOR]' % (title, COLOR1, errors) 
		line2  = '[COLOR %s][B]Size:[/B][/COLOR] [COLOR %s]%s/%s[/COLOR]' % (COLOR3, COLOR2, convertSize(size), zipsize)
		line2 += '[COLOR %s][B] File:[/B][/COLOR] [COLOR %s]%s/%s[/COLOR] ' % (COLOR3, COLOR2, count, int(nFiles))
		line3  = '[COLOR %s]%s[/COLOR]' % (COLOR1, item.filename)
		if skip == True: log("Skipping: %s" % item.filename, xbmc.LOGNOTICE)
		else:
			try:
				zin.extract(item, _out, pwd= PASSWORD)
			except Exception, e:
				errormsg  = "[COLOR %s]File:[/COLOR] [COLOR %s]%s[/COLOR]\n" % (COLOR2, COLOR1, file[-1])
				errormsg += "[COLOR %s]Folder:[/COLOR] [COLOR %s]%s[/COLOR]\n" % (COLOR2, COLOR1, (item.filename).replace(file[-1],''))
				errormsg += "[COLOR %s]Error:[/COLOR] [COLOR %s]%s[/COLOR]\n\n" % (COLOR2, COLOR1, str(e).replace('\\\\','\\').replace("'%s'" % item.filename, ''))
				errors += 1; error += errormsg
				log('Error Extracting: %s(%s)' % (item.filename, str(e)), xbmc.LOGERROR)
				pass
		dp.update(prog, line1, line2, line3)
		if dp.iscanceled(): break
	if dp.iscanceled(): 
		dp.close()
		LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Extract Cancelled[/COLOR]" % COLOR2)
		sys.exit()
	return prog, errors, error