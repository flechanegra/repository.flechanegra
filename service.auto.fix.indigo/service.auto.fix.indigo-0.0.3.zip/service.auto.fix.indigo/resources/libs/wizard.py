# -*- coding: UTF-8 -*-
import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs, glob
import shutil, base64, zlib
import urllib2,urllib
import re
import uservar
import time, downloader, extract
from datetime import date, datetime, timedelta
from resources.libs import autoexec
try:    from sqlite3 import dbapi2 as database
except: from pysqlite2 import dbapi2 as database
from string import digits

ADDON_ID       = uservar.ADDON_ID
ADDONTITLE     = uservar.ADDONTITLE
ADDON          = xbmcaddon.Addon(ADDON_ID)
HOME           = xbmc.translatePath('special://home/')
PLUGIN         = os.path.join(HOME,     'addons',    ADDON_ID)
LOG            = xbmc.translatePath('special://logpath/')
ADDONS         = os.path.join(HOME, 'addons')
USERDATA       = os.path.join(HOME, 'userdata')
ADDONDATA      = os.path.join(USERDATA, 'addon_data', ADDON_ID)
XML            = os.path.join(ADDONS, 'repository.thecrew','addon.xml')
SERVICE        = os.path.join(ADDONS, 'plugin.program.indigo','service.py')
FAVOURITES     = os.path.join(USERDATA, 'favourites.xml')
PROFILES       = os.path.join(USERDATA, 'profiles.xml')
ICON           = os.path.join(PLUGIN, 'icon.png')
WIZLOG         = os.path.join(ADDONDATA, 'wizard.log')
DIALOG         = xbmcgui.Dialog()
dp             = xbmcgui.DialogProgress()
sourcefile     = os.path.join("special://home/addons/plugin.program.indigo/service.py")
myfile         = os.path.join("special://home/addons/repository.thecrew/service.py")



def getS(name):
	try: return ADDON.getSetting(name)
	except: return False


def log(log):
	xbmc.log("[%s]: %s" % (ADDONTITLE, log))
	if not os.path.exists(ADDONDATA): os.makedirs(ADDONDATA)
	if not os.path.exists(WIZLOG): f = open(WIZLOG, 'w'); f.close()
	with open(WIZLOG, 'r+') as f:
		line = "[%s %s] %s" % (datetime.now().date(), str(datetime.now().time())[:8], log)
		content = f.read()
		f.seek(0, 0)
		f.write(line.rstrip('\r\n') + '\n' + content)
		
def LogNotify(title,message,times=4000,icon=ICON):
	xbmc.executebuiltin('XBMC.Notification(%s, %s, %s, %s)' % (title , message , times, icon))
	
def killxbmc(over=False):
    if over: choice = 1						
    else: choice = DIALOG.yesno('[COLOR=green]Fechar o Kodi[/COLOR]', 'Prestes a fechar Kodi!', 'Quer continuar?', nolabel='No, Cancel',yeslabel='[COLOR=green]Yes, Close[/COLOR]')
    if choice == 1:
        myplatform = platform()
        ("Force Closing Kodi: Platform[%s]" % str(platform()), xbmc.LOGNOTICE)
        os._exit(1)

def platform():
	if xbmc.getCondVisibility('system.platform.android'):             return 'android'
	elif xbmc.getCondVisibility('system.platform.linux'):             return 'linux'
	elif xbmc.getCondVisibility('system.platform.linux.Raspberrypi'): return 'linux'
	elif xbmc.getCondVisibility('system.platform.windows'):           return 'windows'
	elif xbmc.getCondVisibility('system.platform.osx'):               return 'osx'
	elif xbmc.getCondVisibility('system.platform.atv2'):              return 'atv2'
	elif xbmc.getCondVisibility('system.platform.ios'):               return 'ios'
	elif xbmc.getCondVisibility('system.platform.darwin'):            return 'ios'
		
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    return link

def Updateaddons():         	        
		autoexec.main()
		DIALOG.ok(ADDONTITLE,'[COLOR springgreen]MUITO IMPORTANTE:[/COLOR]','O complemento atualizado feito desta forma.','Pode dar uso ao repositório [COLOR orchid]THE CREW REPO[/COLOR]!')
		killxbmc(over=False)  
		
def UpdateXml():         
		file = xbmc.translatePath(os.path.join('special://home/addons/repository.thecrew/addon.xml').decode("utf-8"))   		            
		data = "eJy1VlFz2zYMfk5/BabnhHSS7rb2ZPW2nJetlyW9NGkfer0eLMIRE4nUSCqO9+sLUrbjZul1SZQHW5BI4AM+ACTyNzdNDdfkvLZmnO2KUQZkSqu0uRhn52d/7PyavSle5KiUNaDVOHPUWq+DdQsRKiodzTMw2NA4+3RwcnRyCtaVlVafz/6cwMHp5COcTt6dfJJp7XMGrbPXWpHb6XXOKoKDZGPtw0jsi92seLGVO/qn0448y1u5blrrAiRHxtnNtClFkjc0d/fEiAOQUVduKOd0E8jEPXAXtbXahE1z4ja+LOEq7eKTHTAzC6VtWjbqiZmYYe0pK6oQWv9aSodzcaFD1U07T660hjGDYAW55GleyX9162WDPpCTX/hFJkwvOAm5jAA9VMkKV75rhrItGvVzLtdWE4bCgBwb8M5xFlz3xEhyuTSYSJMrYQD2DrtLrEcj6Ru3Cfpk5n5odzDWvoOU5OfjLRA2ndGxO7CWvnTYsrjOWWNVV5N/iXXde/L0Unw04HD1+UAXno99ZadTqrVBuXFg3n4cqogfCjMY0/8P+Pn4xZdXO7Ylw/fJJZVh04v4+W7qh6nwp4EOxv1j3HjGc6YiR1hjcMQXu5eV5R3B2nrtAI8TJL+k7zPN/TfIrfd4zCFvw4d6cW8acrkeUL6dVv47nTTE2myhn03Y/QbdAmqM0xqZrFhNNqA9IMTjEOwMtFGap66OUwqhwgDKkod5lHSAEg0Eu5rMwMaw/DYsbMebCabkeZvhsZAjCqhNE+PP5RK8LyPiotNtiE7fOvM3mkWsKdqGJF5YAdHByC+gUaBI6RIDKUBHENkU8LEXmJtbmwmjZaJn1jUFn965XL/FpVqXzBgVh8fncDg5npz+dgTvzn8/+usA+Dc5fj8R8KGfEmF/G/ZewdvOEOyNRr/kcqXct4Mva9QNuTucYhcq6yKXoYrUpnFYWTA2QGWZoBhfWiVYlgjzq8sqJmJmOw42BlzhNbEO4IzLQWPia861dZ/6alL2kbQ1puc5uF6AJ+QxOyaRptz6FEHcSlXAuWeXQ0wh+zw34LS/+imW2yq8FC1ypwe/7H/WLeKfaM0Fd2XZs76Vz9CgC0X/EJctLy4/pWXOETF9lQ0FnxyMV8Zec0F6L3d7Wxtbfqiy93CV/ftUcrkO7pvuyvtzoPgK9MKVIw=="
		settings = zlib.decompress(base64.b64decode(data))
		s = open(file, 'w')    
		s.write(settings)    
		s.close()  	
	
def UpdateFile(): 			       
		file = xbmc.translatePath(os.path.join('special://home/addons/plugin.program.indigo/addon.xml').decode("utf-8"))   		            		        
		data = "eJytVEtv1DAQPre/YvC5TUrFAaFsKoFUCSEkDkVwnXUmWat+BD82m3/P2NndpqVwIockjud7zMNp7g5Gw558UM5uxNvqRgBZ6Tplh434/nB//V5AiGg71M7SRswUxF172WDXOQuq24hRp0HZavRu8GgqZTs1OPHE+a66qW6Z1qJh/OfjNofvVUf+evkc94UwiPbyovH0KylPgd8vGmVG5yOU7Y04bI2sxjnunF1J3FbZeJ2x9RMY+GroEMnmKBidsvEZQ7VYDy55SQK02nr080Z01GPSkaPEwlKYjo5Dm+8O6EAyRdxqaurz1qJZn0X/aaKkVBmK2GHEtVRIxrAT0Ji7QFa0S9lABZjZLQwYacIZooO4I5ic1x24HpJ1fa+kQg1fuIdL1cKbpj4yrjTYrvRqjNnV/9KBb5owEOxVUBGmaapOfa2kg955CGnM7ayaeqW/dqWC1KgM+ZWpIsGWEDwNKkTy1EH02BHn9Jj9ZHM/P379BPcu8ahm0gp+EKAnsC6CdNaSjBnmgG0oC2hncIzzkBNETkcrzBGTiruS1RU8EJrjK4NeFblPPpMY5+mqcAbXxwnLqmReoDwgXZIxsNe+uN/OkAJLac05SVL77PNUnWzveX3lDjkBzWTKSp3y6Sx2yibXNRmuju1gj145Jg6uYC1FbtljyOU+F3ZV7VzihAO1ZJv6vFiNvMbI7KZFrXnKT6ungCLd7mIcw4e6ftHwejHWLM8VaqItzwf9DdfUp4DViShn9IwYuEdpy7GmPgFZ79U/Ec/+gv3zbDZ1gba/AaKmtdI="		
		settings = zlib.decompress(base64.b64decode(data))		        
		s = open(file, 'w')    		        
		s.write(settings)   		        
		s.close()
	
def InstallRepository():  
    link = OPEN_URL('https://pastebin.com/raw/2AaG9XHq').replace('\n','').replace('\r','')       
    urlzipmatch = re.compile('url="(.+?)"').findall(link)	
    urlzip  = urlzipmatch[0] if (len(urlzipmatch) > 0) else ''		    	
    path = xbmc.translatePath(os.path.join('special://home/addons/packages'))    
    dp = xbmcgui.DialogProgress()    
    dp.create("Instalando [COLOR orchid]THE CREW REPO[/COLOR]!",'Espere um pouco.')    
    lib = os.path.join(path, 'repository.thecrew-0.3.1.zip')   
    addonfolder = xbmc.translatePath(os.path.join('special://home/addons/'))       
    if os.path.exists(lib):
        os.remove(lib)
    downloader.download(urlzip, lib, dp)
    try:	    
		extract.all(lib, addonfolder, dp)    	    	    
		time.sleep(2) 	    	    
		UpdateXml()
		time.sleep(2) 
		Updateaddons()     	
    except IOError, (errno, strerror):
        log("Failed to open required files", "Error code is:", strerror)
        return False	
							
class cacheEntry:
    def __init__(self, namei):
        self.name = namei

def setupXvbmcEntries():
    pathName = [myfile,
				sourcefile]
    entries = (len(myfile + sourcefile)) >0               
    XvbmcEntries = []
    
    for x in range(entries):
        XvbmcEntries.append(cacheEntry(pathName[x]))
    
    return XvbmcEntries  

def clearCache():
    XvbmcEntries = setupXvbmcEntries() 
    for entry in XvbmcEntries:	
        lib = xbmc.translatePath(os.path.join('special://home/addons/plugin.program.indigo/','addon.xml'))  		
        if os.path.exists(lib)==True:
            os.remove(lib)
            LogNotify(ADDONTITLE,'[COLOR yellow]Ficheiro foi apagado:[/COLOR] [COLOR green]Sucesso![/COLOR]')
            UpdateFile()
            InstallRepository()
        else: LogNotify(ADDONTITLE,'[COLOR white]Já não está no seu sistema![/COLOR]')	
    LogNotify(ADDONTITLE, 'Não tem ficheiro para ser eliminado!')	