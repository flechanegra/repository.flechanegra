# -*- coding: UTF-8 -*-
import xbmc, xbmcaddon, xbmcgui
import xbmcplugin, os, sys, re 
import urllib2, urllib, time
import uservar
from resources.libs import wizard as wiz

AddonID = xbmcaddon.Addon().getAddonInfo('id')
ADDON = xbmcaddon.Addon(id=AddonID) 
ADDONTITLE = ADDON.getAddonInfo('name')
DIALOG = xbmcgui.Dialog()
dp = xbmcgui.DialogProgress()
AUTOCLEANUP    = "true"
AUTOCACHE      = "true"


if AUTOCLEANUP == 'true':
	if AUTOCACHE == 'true': wiz.log('[AUTO CLEAN UP][File: on]'); wiz.clearCache()
	else: wiz.log('[AUTO CLEAN UP][File: off]')
else: wiz.log('[AUTO CLEAN UP: off]')
