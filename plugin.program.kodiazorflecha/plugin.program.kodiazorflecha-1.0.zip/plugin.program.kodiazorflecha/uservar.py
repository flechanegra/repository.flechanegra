import os, xbmc, xbmcaddon
import binascii
#########################################################
### User Edit Variables #################################
#########################################################
# Enable/Disable the text file caching with 'Yes' or 'No' and age being how often it rechecks in minutes
CACHETEXT      = 'Yes'
CACHEAGE       = 30

ADDON_ID       = "plugin.program.kodiazorflecha"
ADDONTITLE     = '[COLOR orange][B]KodiazorFlecha Team[/B][/COLOR]'
BUILDERNAME    = 'Playonmonkey'
EXCLUDES       = [ADDON_ID, 'roms', 'My_Builds', 'backupdir']
BUILDFILE      = 'https://cld.pt/dl/download/2a57aa50-7116-4c55-8514-83e0440fb0b4/autobuilds.txt'
UPDATECHECK    = 0
APKFILE        = 'https://cld.pt/dl/download/0f5c08e5-ec79-4ad0-85ef-610ed802172c/apk.txt?download=true'
YOUTUBETITLE   = 'Help Videos' 
YOUTUBEFILE    = 'https://cld.pt/dl/download/cc5de0de-896f-4c7b-98e9-11a8e26bc47c/youtubetheone.txt?download=true'
ADDONFILE      = 'https://cld.pt/dl/download/b6f5c2d0-9907-49ff-81f0-6b003289fa2d/krypton%20advanced.txt?download=true'
ADVANCEDFILE   = 'https://cld.pt/dl/download/b6f5c2d0-9907-49ff-81f0-6b003289fa2d/krypton%20advanced.txt?download=true'
ROMPACK        = ''
EMUAPKS        = ''
ADDONPACK      = 'https://cld.pt/dl/download/dd788059-6300-4d1f-95d3-63b7b44df2a6/addons.txt?download=true'
PATH           = xbmcaddon.Addon().getAddonInfo('path')
ART            = os.path.join(PATH, 'resources', 'art')

#########################################################
### THEMING MENU ITEMS ##################################
#########################################################
# If you want to use locally stored icons the place them in the Resources/Art/
# folder of the wizard then use os.path.join(ART, 'imagename.png')
# do not place quotes around os.path.join
# Example:  ICONMAINT     = os.path.join(ART, 'mainticon.png')
#           ICONSETTINGS  = 'http://aftermathwizard.net/repo/wizard/settings.png'
# Leave as http:// for default icon
ICONBUILDS     = os.path.join(ART, 'https://i.imgur.com/AzX2PXZ.png')
ICONMAINT      = os.path.join(ART, 'https://i.imgur.com/AzX2PXZ.png')
ICONAPK        = os.path.join(ART, 'https://i.imgur.com/AzX2PXZ.png')
ICONADDONS     = os.path.join(ART, 'https://i.imgur.com/AzX2PXZ.png')
ICONYOUTUBE    = os.path.join(ART, 'https://i.imgur.com/AzX2PXZ.png')
ICONSAVE       = os.path.join(ART, 'https://i.imgur.com/AzX2PXZ.png')
ICONTRAKT      = os.path.join(ART, 'https://i.imgur.com/AzX2PXZ.png')
ICONREAL       = os.path.join(ART, 'https://i.imgur.com/AzX2PXZ.png')
ICONLOGIN      = os.path.join(ART, 'https://i.imgur.com/AzX2PXZ.png')
ICONCONTACT    = os.path.join(ART, 'https://i.imgur.com/AzX2PXZ.png')
ICONSETTINGS   = os.path.join(ART, 'https://i.imgur.com/AzX2PXZ.png')
# Hide the ====== seperators 'Yes' or 'No'
HIDESPACERS    = 'No'
# Character used in seperator
SPACER         = '*'

# You can edit these however you want, just make sure that you have a %s in each of the
# THEME's so it grabs the text from the menu item
COLOR1         = 'orange'
COLOR2         = 'orange'
COLOR3         = 'white'
COLOR4         = 'snow'
COLOR5         = 'lime'
# Primary menu items   / %s is the menu item and is required
THEME1         = '[COLOR '+COLOR1+']%s[/COLOR]'
# Build Names          / %s is the menu item and is required
THEME2         = '[COLOR '+COLOR1+']%s[/COLOR]'
# Alternate items      / %s is the menu item and is required
THEME3         = '[COLOR '+COLOR2+']%s[/COLOR]'
# Current Build Header / %s is the menu item and is required
THEME4         = '[COLOR '+COLOR2+']Current Build:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'
# Current Theme Header / %s is the menu item and is required
THEME5         = '[COLOR '+COLOR2+']Current Theme:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'
THEME6         = '[COLOR '+COLOR3+'][B]%s[/B][/COLOR]'

# Message for Contact Page
# Enable 'Contact' menu item 'Yes' hide or 'No' dont hide
HIDECONTACT    = 'Yes'
# You can add \n to do line breaks
CONTACT        = 'Thank you for choosing Sweetwork.\r\nWebsite: http://sweetwork.net\r\nContact us on facebook at https://www.facebook.com/groups/NWICORDCUTTERS'
#Images used for the contact window.  http:// for default icon and fanart
CONTACTICON    = os.path.join(ART, 'https://cld.pt/dl/download/62f12b8e-f3dc-4f2a-b753-41ce5c850e70/icon.png?download=true')
CONTACTFANART  = 'https://cld.pt/dl/download/5c79f179-b7c0-4dcb-a4e7-499baeef1f7f/fanart.jpg'
#########################################################

#########################################################
### AUTO UPDATE #########################################
########## FOR THOSE WITH NO REPO #######################
# Enable Auto Update 'Yes' or 'No'
AUTOUPDATE     = 'Yes'
# Url to wizard version
WIZARDFILE     = 'https://cld.pt/dl/download/2a57aa50-7116-4c55-8514-83e0440fb0b4/autobuilds.txt'
#########################################################

#########################################################
### AUTO INSTALL ########################################
########## REPO IF NOT INSTALLED ########################
# Enable Auto Install 'Yes' or 'No'
AUTOINSTALL    = 'No'
# Addon ID for the repository
REPOID         = ''
# Url to Addons.xml file in your repo folder(this is so we can get the latest version)
REPOADDONXML   = ''
# Url to folder zip is located in
REPOZIPURL     = ''
#########################################################

#########################################################
### NOTIFICATION WINDOW##################################
#########################################################
# Enable Notification screen Yes or No
ENABLE         = 'Yes'
# Url to notification file
NOTIFICATION   = 'https://cld.pt/dl/download/6824263a-afc2-43de-a1ae-b3ba1dc3a388/notify.txt?download=true'
# Use either 'Text' or 'Image'
HEADERTYPE     = 'Text'
# Font size of header
FONTHEADER     = 'Font13'
HEADERMESSAGE  = 'KodiazorFlecha Team'
# url to image if using Image 424x180
HEADERIMAGE    = ''
# Font for Notification Window
FONTSETTINGS   = 'Font12'
# Background for Notification Window
BACKGROUND     = os.path.join(ART, 'https://cld.pt/dl/download/5c79f179-b7c0-4dcb-a4e7-499baeef1f7f/fanart.jpg')
############################    #############################